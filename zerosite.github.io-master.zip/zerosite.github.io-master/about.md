---
layout: page
title: About
permalink: /about/
---

Hello, my name is Deni Setiawan, I am currently studying at a university in Indonesia majoring in Information Systems. Want to know more about me, let's be friend!

email: deni[at]kopiadem.com
