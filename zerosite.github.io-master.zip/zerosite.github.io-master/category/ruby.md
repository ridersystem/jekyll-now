---
layout: posts_by_category
categories: ruby
title: Ruby
permalink: /category/ruby
---